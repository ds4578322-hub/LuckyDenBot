LuckyDenBot - Virtual Casino Telegram bot (demo, virtual coins)

Что внутри:
- bot.py         -- основной код бота
- requirements.txt
- Procfile       -- для Railway/Heroku-like deploy
- Dockerfile     -- если хочешь деплоить в докере
- README.txt     -- эта инструкция

Быстрый старт локально:
1) Установи Python 3.8+
   https://www.python.org/downloads/
2) Склонируй/распакуй проект и перейди в папку LuckyDenBot
3) Установи зависимости:
     pip install -r requirements.txt
4) Экспортируй переменные окружения:
   На Windows (cmd):
     set TELEGRAM_TOKEN=123456:ABC...
     set ADMIN_ID=YOUR_NUMERIC_TELEGRAM_ID
   На Linux/macOS:
     export TELEGRAM_TOKEN=123456:ABC...
     export ADMIN_ID=YOUR_NUMERIC_TELEGRAM_ID
5) Запусти:
     python bot.py
6) Открой бота в Telegram: https://t.me/LuckyDenBot (если создал именно с таким username)

Деплой на Render (быстрая инструкция):
1) Создай репозиторий на GitHub с файлами этого проекта.
2) Зарегистрируйся и зайди в https://render.com
3) Создай новый Web Service -> Connect a repository -> выбери свой репозиторий.
4) В разделе Environment -> Add Environment Variable добавь:
     TELEGRAM_TOKEN  (значение - токен от BotFather)
     ADMIN_ID        (твое numeric Telegram id)
5) Встроенный запуск использует команду из Procfile: web: python bot.py
6) Деплойни — сервис будет работать 24/7, бот будет опрашивать (polling) Telegram.

Деплой на Railway:
1) https://railway.app -> New Project -> Deploy from GitHub repository
2) Добавь переменные окружения так же (TELEGRAM_TOKEN, ADMIN_ID)
3) Railway автоматически запустит контейнер/процесс по Procfile.

Важные примечания:
- Это демо-бот на виртуальные монеты. НЕЛЬЗЯ подключать реальные платежи без лицензий.
- Для стабильного production-режима лучше: использовать webhook + HTTPS, БД PostgreSQL.
- Не делись своим TELEGRAM_TOKEN с другими — он даёт полный контроль над ботом.

Если хочешь, я могу:
- Сгенерировать репозиторий на GitHub со всем автоматически (требует твой доступ) — я не могу делать это сам от твоего имени.
- Добавить webhook-режим вместо polling (понадобится HTTPS).
- Подготовить инструкцию по настройке секретов на Render шаг за шагом с картинками.