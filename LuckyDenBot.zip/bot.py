#!/usr/bin/env python3
    """LuckyDenBot - virtual casino Telegram bot (slots, roulette, dice, leaderboard, daily bonus)
    Usage:
      set environment variables TELEGRAM_TOKEN and ADMIN_ID (numeric)
      then run: python bot.py
    For hosting (Render / Railway) set TELEGRAM_TOKEN and ADMIN_ID in service env vars.
    """
    import logging
    import os
    import sqlite3
    import time
    import random
    from functools import wraps
    from telegram import Update, ParseMode, InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.ext import Updater, CommandHandler, CallbackContext, CallbackQueryHandler

    # Config from environment
    TOKEN = os.environ.get('TELEGRAM_TOKEN')
    ADMIN_ID = os.environ.get('ADMIN_ID')
    if ADMIN_ID is not None:
        try:
            ADMIN_ID = int(ADMIN_ID)
        except:
            ADMIN_ID = None

    STARTING_BALANCE = 1000
    DAILY_BONUS = 200
    DB_PATH = os.environ.get('DB_PATH', 'casino.db')

    if not TOKEN:
        raise SystemExit("ERROR: TELEGRAM_TOKEN environment variable is required")

    # Logging
    logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
    logger = logging.getLogger(__name__)

    # --- Database helpers ---
    def init_db():
        conn = sqlite3.connect(DB_PATH, check_same_thread=False)
        cur = conn.cursor()
        cur.execute("""CREATE TABLE IF NOT EXISTS users (
                        user_id INTEGER PRIMARY KEY,
                        username TEXT,
                        balance INTEGER DEFAULT 0,
                        last_daily INTEGER DEFAULT 0
                       )""")
        conn.commit()
        conn.close()

    def get_conn():
        return sqlite3.connect(DB_PATH, check_same_thread=False)

    def ensure_user(user_id, username=None):
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("SELECT user_id FROM users WHERE user_id = ?", (user_id,))
        if cur.fetchone() is None:
            cur.execute("INSERT INTO users (user_id, username, balance) VALUES (?, ?, ?)", (user_id, username, STARTING_BALANCE))
            conn.commit()
        else:
            if username:
                cur.execute("UPDATE users SET username = ? WHERE user_id = ?", (username, user_id))
                conn.commit()
        conn.close()

    def get_balance(user_id):
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("SELECT balance FROM users WHERE user_id = ?", (user_id,))
        row = cur.fetchone()
        conn.close()
        return row[0] if row else None

    def change_balance(user_id, delta):
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (delta, user_id))
        conn.commit()
        conn.close()

    def set_last_daily(user_id, ts):
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("UPDATE users SET last_daily = ? WHERE user_id = ?", (ts, user_id))
        conn.commit()
        conn.close()

    def get_last_daily(user_id):
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("SELECT last_daily FROM users WHERE user_id = ?", (user_id,))
        row = cur.fetchone()
        conn.close()
        return row[0] if row else 0

    def top_players(limit=10):
        conn = get_conn()
        cur = conn.cursor()
        cur.execute("SELECT username, balance FROM users ORDER BY balance DESC LIMIT ?", (limit,))
        rows = cur.fetchall()
        conn.close()
        return rows

    # Admin decorator
    def admin_only(func):
        @wraps(func)
        def wrapped(update: Update, context: CallbackContext, *args, **kwargs):
            user = update.effective_user
            if ADMIN_ID is None or user.id != ADMIN_ID:
                update.message.reply_text("Только админ может выполнять эту команду.")
                return
            return func(update, context, *args, **kwargs)
        return wrapped

    # --- Bot commands ---
    def start(update: Update, context: CallbackContext):
        user = update.effective_user
        ensure_user(user.id, user.username or user.full_name)
        kb = InlineKeyboardMarkup([[InlineKeyboardButton("🎰 Слоты", callback_data="play_slots"),
                                    InlineKeyboardButton("🎲 Кости", callback_data="play_dice")],
                                   [InlineKeyboardButton("🎡 Рулетка", callback_data="play_roulette"),
                                    InlineKeyboardButton("🏆 Лидерборд", callback_data="leaderboard")]])
        update.message.reply_text(
            f"Привет, {user.first_name}! Добро пожаловать в LuckyDenBot — демо-казино на виртуальные монеты.\n"
            f"Твой стартовый баланс: {STARTING_BALANCE} 💎\n"
            f"Команды: /balance /daily /slots <ставка> /dice <ставка> /roulette <ставка> /leaderboard",
            reply_markup=kb
        )

    def balance_cmd(update: Update, context: CallbackContext):
        user = update.effective_user
        ensure_user(user.id, user.username or user.full_name)
        bal = get_balance(user.id)
        update.message.reply_text(f"Твой баланс: {bal} 💎")

    def daily(update: Update, context: CallbackContext):
        user = update.effective_user
        ensure_user(user.id, user.username or user.full_name)
        last = get_last_daily(user.id)
        now = int(time.time())
        if now - last < 24*3600:
            remaining = 24*3600 - (now - last)
            hrs = remaining // 3600
            mins = (remaining % 3600) // 60
            update.message.reply_text(f"Бонус можно получить через {hrs} ч {mins} мин.")
            return
        change_balance(user.id, DAILY_BONUS)
        set_last_daily(user.id, now)
        update.message.reply_text(f"Ты получил ежедневный бонус: {DAILY_BONUS} 💎")

    def slots_cmd(update: Update, context: CallbackContext):
        user = update.effective_user
        ensure_user(user.id, user.username or user.full_name)
        args = context.args
        if not args:
            update.message.reply_text("Использование: /slots <ставка>")
            return
        try:
            bet = int(args[0])
        except ValueError:
            update.message.reply_text("Ставка должна быть целым числом.")
            return
        bal = get_balance(user.id)
        if bet <= 0:
            update.message.reply_text("Ставка должна быть положительной.")
            return
        if bet > bal:
            update.message.reply_text("Недостаточно средств.")
            return

        symbols = ["🍒","🍋","🔔","⭐","7️⃣"]
        r = [random.choice(symbols) for _ in range(3)]

        reward = 0
        if r[0] == r[1] == r[2]:
            if r[0] == "7️⃣": reward = bet * 10
            else: reward = bet * 5
        elif r[0] == r[1] or r[1] == r[2] or r[0] == r[2]:
            reward = bet * 2
        else:
            reward = -bet

        change_balance(user.id, reward)
        new_bal = get_balance(user.id)
        result = " | ".join(r)
        if reward > 0:
            update.message.reply_text(f"{result}\nПоздравляем! +{reward} 💎\nБаланс: {new_bal} 💎")
        else:
            update.message.reply_text(f"{result}\nУвы — проигрыш {bet} 💎\nБаланс: {new_bal} 💎")

    def dice_cmd(update: Update, context: CallbackContext):
        user = update.effective_user
        ensure_user(user.id, user.username or user.full_name)
        args = context.args
        if not args:
            update.message.reply_text("Использование: /dice <ставка>")
            return
        try:
            bet = int(args[0])
        except ValueError:
            update.message.reply_text("Ставка должна быть целым числом.")
            return
        bal = get_balance(user.id)
        if bet <= 0 or bet > bal:
            update.message.reply_text("Неправильная ставка или недостаточно средств.")
            return
        roll = random.randint(1,6)
        # выигрыш при 6, возврат при 4-5, проигрыш при 1-3
        if roll == 6:
            reward = bet * 3
        elif roll >=4:
            reward = 0
        else:
            reward = -bet
        change_balance(user.id, reward)
        new_bal = get_balance(user.id)
        update.message.reply_text(f"Бросок: {roll}.
{'Вы выиграли +' + str(reward) if reward>0 else ('Ничья' if reward==0 else 'Проигрыш ' + str(-reward))} 💎\nБаланс: {new_bal} 💎")

    def roulette_cmd(update: Update, context: CallbackContext):
        user = update.effective_user
        ensure_user(user.id, user.username or user.full_name)
        args = context.args
        if not args:
            update.message.reply_text("Использование: /roulette <ставка>\nПример: /roulette 50 (поставить на цвет: бот случайно выбирает выигрыш/проигрыш)")
            return
        try:
            bet = int(args[0])
        except ValueError:
            update.message.reply_text("Ставка должна быть целым числом.")
            return
        bal = get_balance(user.id)
        if bet <= 0 or bet > bal:
            update.message.reply_text("Неправильная ставка или недостаточно средств.")
            return
        # простая рулетка — 18/37 шанс выиграть 2x (европейская упрощённая логика)
        pocket = random.randint(0,36)
        # выигрыш если pocket не 0 и (pocket % 2 == 0) - условно "черный"
        win = (pocket != 0 and pocket % 2 == 0)
        if win:
            reward = bet * 2
        else:
            reward = -bet
        change_balance(user.id, reward)
        new_bal = get_balance(user.id)
        update.message.reply_text(f"Колесо: {pocket}. {'Вы выиграли!' if reward>0 else 'Проигрыш.'} {'+'+str(reward) if reward>0 else str(reward)} 💎\nБаланс: {new_bal} 💎")

    def leaderboard_cmd(update: Update, context: CallbackContext):
        rows = top_players(10)
        if not rows:
            update.message.reply_text("Нет игроков.")
            return
        text = "*Лидерборд по балансу:*\n"
        for i, (username, bal) in enumerate(rows, start=1):
            username_disp = username if username else "—"
            text += f"{i}. {username_disp}: {bal} 💎\n"
        update.message.reply_text(text, parse_mode=ParseMode.MARKDOWN)

    @admin_only
    def admin_add(update: Update, context: CallbackContext):
        args = context.args
        if len(args) < 2:
            update.message.reply_text("Использование: /admin_add <user_id> <amount>")
            return
        try:
            target = int(args[0])
            amount = int(args[1])
        except ValueError:
            update.message.reply_text("Неверные параметры.")
            return
        ensure_user(target)
        change_balance(target, amount)
        update.message.reply_text(f"Добавлено {amount} монет пользователю {target}.")

    def button_handler(update: Update, context: CallbackContext):
        query = update.callback_query
        query.answer()
        data = query.data
        if data == 'play_slots':
            query.message.reply_text('Использование: /slots <ставка> — например /slots 50')
        elif data == 'play_dice':
            query.message.reply_text('Использование: /dice <ставка> — например /dice 20')
        elif data == 'play_roulette':
            query.message.reply_text('Использование: /roulette <ставка> — например /roulette 100')
        elif data == 'leaderboard':
            # call leaderboard in context of message
            class C: pass
            c = C()
            c.args = []
            leaderboard_cmd(update, context)

    def unknown(update: Update, context: CallbackContext):
        update.message.reply_text('Команда не распознана. Используй /start для списка команд.')

    def main():
        init_db()
        updater = Updater(token=TOKEN, use_context=True)
        dp = updater.dispatcher

        dp.add_handler(CommandHandler('start', start))
        dp.add_handler(CommandHandler('balance', balance_cmd))
        dp.add_handler(CommandHandler('daily', daily))
        dp.add_handler(CommandHandler('slots', slots_cmd))
        dp.add_handler(CommandHandler('dice', dice_cmd))
        dp.add_handler(CommandHandler('roulette', roulette_cmd))
        dp.add_handler(CommandHandler('leaderboard', leaderboard_cmd))
        dp.add_handler(CommandHandler('admin_add', admin_add))
        dp.add_handler(CallbackQueryHandler(button_handler))
        dp.add_handler(CommandHandler([], unknown))

        logger.info('Starting LuckyDenBot...')
        updater.start_polling()
        updater.idle()

    if __name__ == '__main__':
        main()